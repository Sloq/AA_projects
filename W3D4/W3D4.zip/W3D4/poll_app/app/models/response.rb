class Response < ApplicationRecord
end
