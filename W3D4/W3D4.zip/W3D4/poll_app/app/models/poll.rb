class Poll < ApplicationRecord
end
