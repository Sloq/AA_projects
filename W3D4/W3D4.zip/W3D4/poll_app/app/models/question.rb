class Question < ApplicationRecord
end
