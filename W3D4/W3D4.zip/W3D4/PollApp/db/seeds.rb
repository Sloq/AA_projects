# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


user1 = User.create!(user_name: "John")
user2 = User.create!(user_name: "Jain")

poll1 = Poll.create!(title: "Our great poll", user_id: user1.id)

question1 = Question.create(text: "hows it going?", poll_id: poll1.id)

answer_choice1 = AnswerChoice.create(text: "its going great", question_id: question1.id)

response1 = Response.create(answer_choice_id: answer_choice1.id, user_id: user1.id)
